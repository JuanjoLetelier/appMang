export interface Product{
        name: string,
        image: string,
        typology: string,
        category: string,
        id: string,
        views: number
}